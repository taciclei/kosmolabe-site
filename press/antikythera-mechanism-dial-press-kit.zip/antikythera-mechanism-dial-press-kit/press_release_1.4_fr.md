# COMMUNIQUÉ DE PRESSE — DIFFUSION IMMÉDIATE

## Machine d'Anticythère arrive sur iPad

**Le cadran avant du calculateur astronomique de la Grèce antique, calculé par ses engrenages, désormais sur iPad comme sur iPhone, Mac, Apple Watch et Apple TV. Gratuite, sans publicité, sans compte, aucune donnée collectée.**

Le 30 octobre 2026 — Machine d'Anticythère (Antikythera Mechanism Dial en anglais), l'app qui fait revivre le cadran avant de la machine d'Anticythère, est disponible sur iPad avec la version 1.4. Sur iPad, l'app affiche un grand cadran et, en paysage, une colonne pour la date, les astres et la manivelle. Un très grand widget d'écran d'accueil montre le cadran et les astres.

**Une machine sortie d'une épave.** En 1900, des pêcheurs d'éponges découvrent une épave antique au large de l'île grecque d'Anticythère. Parmi les objets remontés en 1900-1901 figurent des blocs de bronze corrodés, sur lesquels on remarque en 1902 une roue dentée. Ce sont les restes de la machine d'Anticythère, un calculateur astronomique à manivelle construit au IIe ou au Ier siècle av. J.-C., la plus ancienne machine à engrenages complexe connue. Ses fragments sont conservés au Musée national archéologique d'Athènes.

**Ce que fait l'app.**
- **Le cadran.** Le Soleil, la Lune et sa phase, Mercure, Vénus, Mars, Jupiter et Saturne parcourent l'anneau du zodiaque, calculés à partir des rapports d'engrenages de la reconstruction de Freeth et al. (*Scientific Reports*, 2021). Une molette fait défiler les heures, les jours, les mois lunaires et les années ; sur Apple Watch, la Digital Crown sert de manivelle.
- **Les éclipses.** Un compte à rebours jusqu'à la prochaine éclipse prédite par la machine, avec l'annonce du cadran du Saros, comparée à l'éclipse réelle quand elle est connue. Pour l'éclipse annulaire de Soleil du 6 février 2027, la machine est en avance de 3,3 heures.
- **Le Mécanisme** (iOS et iPadOS 18 et plus). On soulève la plaque de bronze : les roues reconstruites tournent avec les aiguilles, avec une vue éclatée et le statut de chaque pièce : conservée, reconstruite ou hypothétique.
- **Le Ciel réel** (iOS et iPadOS 18 et plus ; Apple Watch avec boussole). On lève l'appareil et chaque aiguille vise le vrai Soleil, la vraie Lune et les vraies planètes ; le sélecteur « Ciel / Machine » montre de combien la machine antique s'écarte du ciel.
- **La musique antique**, désactivée par défaut : Hymne hourrite n° 6, Épitaphe de Seikilos et Hymnes delphiques, joués par la synthèse propre de l'app.

**Une méthode ouverte.** L'app s'appuie sur une reconstruction 3D ouverte du mécanisme (github.com/taciclei/antikythera-mechanism). D'après ce dépôt, ses 22 cibles d'engrenages sont atteintes exactement, en fractions (la Lune fait 254/19 tours par an), et chacune des 69 roues est marquée conservée (30), reconstruite (7) ou hypothétique (32).

**Confidentialité.** L'app n'a ni compte, ni publicité, ni statistiques, ni suivi, ni SDK tiers, ni connexion à Internet. La position, utilisée seulement pour le Ciel réel et la Boussole, reste sur l'appareil, sauf à l'Apple TV de l'utilisateur, arrondie à une dizaine de kilomètres, quand il la calibre.

**Disponibilité.** Machine d'Anticythère 1.4 est gratuite sur l'App Store, sans achat intégré, en neuf langues (français, anglais, allemand, grec, espagnol, italien, japonais, portugais du Brésil et chinois simplifié). Configuration : iOS ou iPadOS 17 et plus, macOS 14 et plus, watchOS 10 et plus, tvOS 17 et plus.

- App Store : https://apps.apple.com/app/id6820847358
- Site : https://taciclei.github.io/kosmolabe-site/fr.html
- Kit presse (icônes, rendus, captures) : https://taciclei.github.io/kosmolabe-site/press.html#fr

**À propos du développeur.** taciclei est le développeur indépendant de Machine d'Anticythère (Antikythera Mechanism Dial), une app gratuite pour iPhone, iPad, Mac, Apple Watch et Apple TV. L'app s'appuie sur la reconstruction 3D ouverte de la machine d'Anticythère publiée par taciclei (github.com/taciclei/antikythera-mechanism) : un modèle Blender, une spécification exacte des rapports d'engrenages et des preuves en Lean 4, code sous licence MIT, médias sous CC BY 4.0. La reconstruction suit le modèle publié de T. Freeth et al. (Scientific Reports, 2021) ; le dépôt de recherche indique qu'elle a été réalisée avec Claude Code (Anthropic) pour taciclei.

**Crédits.** Reconstruction de la machine d'Anticythère par taciclei (CC BY 4.0) ; d'après T. Freeth et al., *Scientific Reports* 11, 5821 (2021). Modèle magnétique WMM2025 (NOAA, BGS).

**Contact presse :** taciclei, taciclei@gmail.com

###
