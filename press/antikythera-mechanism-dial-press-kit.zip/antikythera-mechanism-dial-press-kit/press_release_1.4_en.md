# PRESS RELEASE — FOR IMMEDIATE RELEASE

## Antikythera Mechanism Dial comes to iPad

**The front dial of the ancient Greek astronomical calculator, computed from its gears, now on iPad as well as iPhone, Mac, Apple Watch and Apple TV. Free, no ads, no account, no data collected.**

October 30, 2026 — Antikythera Mechanism Dial (Machine d'Anticythère in French), the app that brings back the front dial of the Antikythera Mechanism, is now available on iPad with version 1.4. On iPad the app shows a large dial and, in landscape, a column for the date, the celestial bodies and the crank. An extra-large Home Screen widget shows the dial and the celestial bodies.

**A machine from a shipwreck.** In 1900, sponge divers found an ancient wreck off the Greek island of Antikythera. Among the objects raised in 1900–1901 were corroded lumps of bronze, on which a gear wheel was noticed in 1902. They are the remains of the Antikythera Mechanism, a hand-cranked astronomical calculator built in the 2nd or 1st century BC and the oldest known complex geared machine. Its fragments are kept at the National Archaeological Museum in Athens.

**What the app does.**
- **The dial.** The Sun, the Moon with its phase, Mercury, Venus, Mars, Jupiter and Saturn move around the zodiac ring, computed from the gear ratios of the reconstruction by Freeth et al. (*Scientific Reports*, 2021). A wheel runs through hours, days, lunar months and years; on Apple Watch the Digital Crown is the crank.
- **Eclipses.** A countdown to the next eclipse predicted by the machine, with the Saros dial's announcement, compared with the real eclipse when it is known. For the annular solar eclipse of 6 February 2027, the machine is 3.3 hours early.
- **The Mechanism** (iOS and iPadOS 18 or later). Lift the bronze plate and the reconstructed wheels turn with the pointers, with an exploded view and the status of each part: surviving, reconstructed or hypothetical.
- **Real Sky** (iOS and iPadOS 18 or later; Apple Watch with a compass). Raise the device and each pointer aims at the real Sun, Moon and planets; a “Sky / Machine” switch shows how far the ancient machine drifts from the sky.
- **Ancient music**, off by default: Hurrian Hymn No. 6, the Seikilos Epitaph and the Delphic Hymns, played by the app's own synthesis.

**Open method.** The app is based on an open 3D reconstruction of the mechanism (github.com/taciclei/antikythera-mechanism). According to that repository, its 22 gear-train targets match exactly as fractions (the Moon turns 254/19 times per year), and each of the 69 gears is tagged as surviving (30), reconstructed (7) or hypothetical (32).

**Privacy.** The app has no account, no advertising, no analytics, no tracking, no third-party SDK and no internet connection. Location, used only for Real Sky and Compass, stays on the device, except that it is sent, rounded to about ten kilometres, to the user's own Apple TV when they calibrate it.

**Availability.** Antikythera Mechanism Dial 1.4 is free on the App Store, with no in-app purchase, in nine languages (English, French, German, Greek, Spanish, Italian, Japanese, Portuguese (Brazil) and Simplified Chinese). Requirements: iOS or iPadOS 17 or later, macOS 14 or later, watchOS 10 or later, tvOS 17 or later.

- App Store: https://apps.apple.com/app/id6820847358
- Website: https://taciclei.github.io/kosmolabe-site/
- Press kit (icons, renders, screenshots): https://taciclei.github.io/kosmolabe-site/press.html

**About the developer.** taciclei is the independent developer of Antikythera Mechanism Dial (Machine d'Anticythère), a free app for iPhone, iPad, Mac, Apple Watch and Apple TV. The app is based on taciclei's open 3D reconstruction of the Antikythera Mechanism (github.com/taciclei/antikythera-mechanism): a Blender model, an exact gear-ratio specification and Lean 4 proofs, with code under MIT and media under CC BY 4.0. The reconstruction follows the published model of T. Freeth et al. (Scientific Reports, 2021); the research repository states that it was built with Claude Code (Anthropic) for taciclei.

**Credits.** Antikythera Mechanism reconstruction by taciclei (CC BY 4.0); after T. Freeth et al., *Scientific Reports* 11, 5821 (2021). WMM2025 magnetic model (NOAA, BGS).

**Press contact:** taciclei, taciclei@gmail.com

###
