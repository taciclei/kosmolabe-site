# Developer bio / Biographie du développeur

> Neutral text built only from what the repositories state. / Texte neutre, construit uniquement à partir de ce que disent les dépôts.

## English (5 lines)

taciclei is the independent developer of Antikythera Mechanism Dial (Machine d'Anticythère), a free app for iPhone, iPad, Mac, Apple Watch and Apple TV.
The app is based on taciclei's open 3D reconstruction of the Antikythera Mechanism (github.com/taciclei/antikythera-mechanism): a Blender model, an exact gear-ratio specification and Lean 4 proofs, with code under MIT and media under CC BY 4.0.
The reconstruction follows the published model of T. Freeth et al. (Scientific Reports, 2021); the research repository states that it was built with Claude Code (Anthropic) for taciclei.
Contact: taciclei@gmail.com (the address published on the app's support page).

## Français (5 lignes)

taciclei est le développeur indépendant de Machine d'Anticythère (Antikythera Mechanism Dial), une app gratuite pour iPhone, iPad, Mac, Apple Watch et Apple TV.
L'app s'appuie sur la reconstruction 3D ouverte de la machine d'Anticythère publiée par taciclei (github.com/taciclei/antikythera-mechanism) : un modèle Blender, une spécification exacte des rapports d'engrenages et des preuves en Lean 4, code sous licence MIT, médias sous CC BY 4.0.
La reconstruction suit le modèle publié de T. Freeth et al. (Scientific Reports, 2021) ; le dépôt de recherche indique qu'elle a été réalisée avec Claude Code (Anthropic) pour taciclei.
Contact : taciclei@gmail.com (l’adresse publiée sur la page d’assistance de l’app).
