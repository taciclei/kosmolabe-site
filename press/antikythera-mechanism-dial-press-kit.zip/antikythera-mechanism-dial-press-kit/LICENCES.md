# Licences / Licences d'utilisation

- **Renders (`renders/`)** — Antikythera Mechanism reconstruction by taciclei, **CC BY 4.0**
  (https://creativecommons.org/licenses/by/4.0/). Credit: “Antikythera Mechanism reconstruction by taciclei”,
  and indicate if changes were made. Source: github.com/taciclei/antikythera-mechanism (`LICENSE-MEDIA.md`).
  / **Rendus** : CC BY 4.0, crédit « Antikythera Mechanism reconstruction by taciclei », en indiquant les modifications.
- **App icon and screenshots (`icons/`, `screenshots/`)** — © 2026 taciclei, also under the repository's MIT licence. May be reproduced for editorial
  coverage of the app (articles, reviews, videos), unmodified except for resizing or cropping.
  / **Icône et captures** : © 2026 taciclei, reproduction autorisée pour la couverture éditoriale de l'app, sans
  modification autre que redimensionnement ou recadrage.
- **Explainer film** “Le ciel dans une boîte” (https://youtu.be/eXvYkouJy_w) — **link only, not included**: its
  voice-over was generated with Voxtral TTS, whose weights are licensed CC BY-NC 4.0, so the film is for
  non-commercial use. / **Film explicatif** : lien seulement, non inclus (voix off sous contrainte CC BY-NC 4.0,
  usage non commercial).
- **Scholarly data** — T. Freeth et al., “A Model of the Cosmos in the ancient Greek Antikythera Mechanism”,
  *Scientific Reports* 11, 5821 (2021). Please cite it. / **Données savantes** : merci de citer cet article.
- Apple, App Store, iPhone, iPad, Mac, Apple Watch, Apple TV and Digital Crown are trademarks of Apple Inc.
