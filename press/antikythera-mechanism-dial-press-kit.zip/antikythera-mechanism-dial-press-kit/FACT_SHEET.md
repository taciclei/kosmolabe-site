# Antikythera Mechanism Dial / Machine d'Anticythère — Fact sheet / Fiche technique

| | |
|---|---|
| App Store | https://apps.apple.com/app/id6820847358 (id 6820847358) |
| Website / Site | https://taciclei.github.io/kosmolabe-site/ |
| Version | 1.4 (iPad launch / arrivée sur iPad) |
| Release date / Date de sortie | [date de sortie / release date] |
| Developer / Développeur | taciclei |
| Price / Prix | Free, no in-app purchase / Gratuite, sans achat intégré |
| Platforms / Plateformes | iPhone (iOS 17+), iPad (iPadOS 17+), Mac (macOS 14+), Apple Watch (watchOS 10+), Apple TV (tvOS 17+); one universal purchase / un seul achat universel |
| Mechanism view, Real Sky / Vue Mécanisme, Ciel réel | iPhone and iPad with iOS 18+ (Real Sky also on Apple Watch with a compass) |
| Category / Catégorie | Education (secondary: Reference) / Éducation (secondaire : Référence) |
| Privacy / Confidentialité | Data Not Collected: no account, no ads, no analytics, no tracking, no third-party SDK, no internet connection / Données non collectées |
| Languages / Langues | fr, en, de, el, es, it, ja, pt-BR, zh-Hans |
| Based on / D'après | T. Freeth et al., Scientific Reports 11, 5821 (2021); open reconstruction github.com/taciclei/antikythera-mechanism (code MIT, media CC BY 4.0) |
| Contact | [contact presse / press contact] |

## Name per language / Nom par langue

| Language | App Store name | Subtitle |
|---|---|---|
| Français (`fr-FR`) | Machine d'Anticythère | L'ordinateur grec antique |
| English (`en-US`) | Antikythera Mechanism Dial | The ancient Greek computer |
| Deutsch (`de-DE`) | Mechanismus von Antikythera | Antiker griechischer Computer |
| Ελληνικά (`el`) | Μηχανισμός των Αντικυθήρων | Αρχαίος ελληνικός υπολογιστής |
| Español (`es-ES`) | Mecanismo de Anticitera | El ordenador griego antiguo |
| Italiano (`it`) | Macchina di Anticitera | L'antico computer greco |
| 日本語 (`ja`) | アンティキティラ島の機械 | 古代ギリシャのコンピュータ |
| Português (Brasil) (`pt-BR`) | Máquina de Anticítera | O computador grego antigo |
| 简体中文 (`zh-Hans`) | 安提基特拉机械 | 古希腊的天文计算机 |

“Antikythera Mechanism Dial” is the app; “the Antikythera Mechanism” is the historical object. /
« Machine d'Anticythère » est l'app ; « la machine d'Anticythère » est l'objet historique.
